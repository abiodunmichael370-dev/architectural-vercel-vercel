CREATE TABLE IF NOT EXISTS tomzy_leads (
  id TEXT PRIMARY KEY,
  channel TEXT NOT NULL,
  wa_id TEXT,
  name TEXT,
  email TEXT,
  phone TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  summary TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS tomzy_messages (
  id BIGSERIAL PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES tomzy_leads(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  channel TEXT NOT NULL,
  external_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tomzy_messages_lead_idx ON tomzy_messages(lead_id, created_at);
