import { askAI } from './_lib/ai.js';
import { addMessage, getHistory, getLead, upsertLead } from './_lib/db.js';

const fallback = 'I can help with TOMZY ARCHITECTURAL services, project requirements, permit documentation, technical/structural drawing support, 3D visualization and engineering stamp/seal coordination. Tell me your project type, location and what you need delivered.';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { message, leadId } = req.body || {};
    if (!message || typeof message !== 'string') return res.status(400).json({ error: 'Message required' });
    const id = leadId || crypto.randomUUID();
    await upsertLead({ id, channel: 'website', status: 'new' });
    const history = await getHistory(id);
    await addMessage({ leadId: id, role: 'user', content: message, channel: 'website' });
    const answer = await askAI({ message, history, lead: await getLead(id) }) || fallback;
    await addMessage({ leadId: id, role: 'assistant', content: answer, channel: 'website' });
    return res.status(200).json({ answer, leadId: id });
  } catch (error) {
    return res.status(500).json({ error: 'Unexpected server error' });
  }
}
