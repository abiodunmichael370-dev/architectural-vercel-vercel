import crypto from 'crypto';
import getRawBody from 'raw-body';
import { askAI } from '../_lib/ai.js';
import { addMessage, getHistory, getLead, upsertLead } from '../_lib/db.js';
import { sendWhatsAppText } from '../_lib/whatsapp.js';

export const config = { api: { bodyParser: false } };

function validSignature(raw, signature) {
  if (!process.env.META_APP_SECRET || !signature) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', process.env.META_APP_SECRET).update(raw).digest('hex');
  const a = Buffer.from(expected); const b = Buffer.from(signature || '');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const mode = req.query?.['hub.mode'];
    const token = req.query?.['hub.verify_token'];
    const challenge = req.query?.['hub.challenge'];
    if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) return res.status(200).send(challenge);
    return res.status(403).send('Forbidden');
  }
  if (req.method !== 'POST') return res.status(405).send('Method not allowed');
  try {
    const rawBuffer = await getRawBody(req);
    const raw = rawBuffer.toString('utf8');
    if (!validSignature(raw, req.headers['x-hub-signature-256'])) return res.status(401).send('Invalid signature');
    const body = JSON.parse(raw);
    const value = body?.entry?.[0]?.changes?.[0]?.value;
    const msg = value?.messages?.[0];
    if (!msg || msg.type !== 'text' || !msg.from) return res.status(200).send('EVENT_RECEIVED');
    const from = msg.from;
    const name = value?.contacts?.[0]?.profile?.name || '';
    const text = msg.text?.body?.trim();
    if (!text) return res.status(200).send('EVENT_RECEIVED');
    const leadId = `wa_${from}`;
    await upsertLead({ id: leadId, channel: 'whatsapp', wa_id: from, name, phone: from, status: 'active' });
    const history = await getHistory(leadId);
    await addMessage({ leadId, role: 'user', content: text, channel: 'whatsapp', externalId: msg.id });
    const answer = await askAI({ message: text, history, lead: await getLead(leadId) }) || 'Thanks for reaching out. Please share your project type, location and what you need delivered, and Micheal will review the project details.';
    await addMessage({ leadId, role: 'assistant', content: answer, channel: 'whatsapp' });
    await sendWhatsAppText(from, answer);
    if (process.env.ADMIN_WHATSAPP_TO && /quote|price|cost|budget|stamp|seal|rush|urgent|negotiate|discount|approve/i.test(text)) {
      try { await sendWhatsAppText(process.env.ADMIN_WHATSAPP_TO, `Client conversation needs review\n\n${name || 'WhatsApp client'} (${from})\n\nClient: ${text}\n\nAI reply: ${answer}`.slice(0, 3900)); } catch (_) {}
    }
    return res.status(200).send('EVENT_RECEIVED');
  } catch (_) { return res.status(500).send('Webhook error'); }
}
