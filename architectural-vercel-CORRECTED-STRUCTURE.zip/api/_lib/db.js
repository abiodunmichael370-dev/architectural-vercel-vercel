let sqlClient;

async function getSql() {
  if (!process.env.DATABASE_URL) return null;
  if (!sqlClient) {
    const { neon } = await import('@neondatabase/serverless');
    sqlClient = neon(process.env.DATABASE_URL);
  }
  return sqlClient;
}

export async function dbEnabled() { return Boolean(process.env.DATABASE_URL); }

export async function ensureSchema() {
  const sql = await getSql();
  if (!sql) return false;
  await sql`CREATE TABLE IF NOT EXISTS tomzy_leads (
    id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    wa_id TEXT,
    name TEXT,
    email TEXT,
    phone TEXT,
    status TEXT NOT NULL DEFAULT 'new',
    summary TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS tomzy_messages (
    id BIGSERIAL PRIMARY KEY,
    lead_id TEXT NOT NULL REFERENCES tomzy_leads(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    channel TEXT NOT NULL,
    external_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE INDEX IF NOT EXISTS tomzy_messages_lead_idx ON tomzy_messages(lead_id, created_at)`;
  return true;
}

export async function upsertLead(lead) {
  const sql = await getSql();
  if (!sql) return lead;
  await ensureSchema();
  await sql`INSERT INTO tomzy_leads (id, channel, wa_id, name, email, phone, status, summary, metadata)
    VALUES (${lead.id}, ${lead.channel}, ${lead.wa_id || null}, ${lead.name || null}, ${lead.email || null}, ${lead.phone || null}, ${lead.status || 'new'}, ${lead.summary || null}, ${JSON.stringify(lead.metadata || {})}::jsonb)
    ON CONFLICT (id) DO UPDATE SET
      channel=EXCLUDED.channel, wa_id=COALESCE(EXCLUDED.wa_id, tomzy_leads.wa_id), name=COALESCE(EXCLUDED.name, tomzy_leads.name),
      email=COALESCE(EXCLUDED.email, tomzy_leads.email), phone=COALESCE(EXCLUDED.phone, tomzy_leads.phone),
      status=COALESCE(EXCLUDED.status, tomzy_leads.status), summary=COALESCE(EXCLUDED.summary, tomzy_leads.summary),
      metadata=tomzy_leads.metadata || EXCLUDED.metadata, updated_at=NOW()`;
  return lead;
}

export async function addMessage({ leadId, role, content, channel, externalId = null }) {
  const sql = await getSql();
  if (!sql) return;
  await ensureSchema();
  await sql`INSERT INTO tomzy_messages (lead_id, role, content, channel, external_id) VALUES (${leadId}, ${role}, ${content}, ${channel}, ${externalId})`;
  await sql`UPDATE tomzy_leads SET updated_at=NOW() WHERE id=${leadId}`;
}

export async function getHistory(leadId) {
  const sql = await getSql();
  if (!sql) return [];
  await ensureSchema();
  const rows = await sql`SELECT role, content FROM tomzy_messages WHERE lead_id=${leadId} ORDER BY created_at DESC LIMIT 12`;
  return rows.reverse();
}

export async function getLead(leadId) {
  const sql = await getSql();
  if (!sql) return null;
  await ensureSchema();
  const rows = await sql`SELECT * FROM tomzy_leads WHERE id=${leadId} LIMIT 1`;
  return rows[0] || null;
}
