export default async function handler(req, res) {
  res.status(200).json({ ok: true, service: 'TOMZY ARCHITECTURAL backend', whatsapp: Boolean(process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_ACCESS_TOKEN), ai: Boolean(process.env.OPENAI_API_KEY && process.env.OPENAI_MODEL), database: Boolean(process.env.DATABASE_URL) });
}
