import { upsertLead } from './_lib/db.js';
import { sendWhatsAppText } from './_lib/whatsapp.js';

function clean(v, max = 2000) { return typeof v === 'string' ? v.trim().slice(0, max) : ''; }

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lead = {
      id: clean(b.leadId, 100) || crypto.randomUUID(), channel: 'website', status: 'quote_requested',
      name: clean(b.name, 120), email: clean(b.email, 200), phone: clean(b.phone, 80),
      summary: clean(b.description, 3000), metadata: {
        projectType: clean(b.projectType, 120), service: clean(b.service, 120), location: clean(b.location, 200),
        size: clean(b.size, 120), timeframe: clean(b.timeframe, 120), existingFiles: clean(b.existingFiles, 120), budget: clean(b.budget, 120)
      }
    };
    await upsertLead(lead);
    if (process.env.ADMIN_WHATSAPP_TO) {
      const text = `New website quote request\n\nName: ${lead.name || 'Not provided'}\nProject: ${lead.metadata.projectType}\nService: ${lead.metadata.service}\nLocation: ${lead.metadata.location}\nSize: ${lead.metadata.size || 'Not provided'}\nTimeframe: ${lead.metadata.timeframe || 'Not provided'}\nBudget: ${lead.metadata.budget || 'Not provided'}\n\n${lead.summary}`;
      try { await sendWhatsAppText(process.env.ADMIN_WHATSAPP_TO, text.slice(0, 3900)); } catch (_) {}
    }
    return res.status(200).json({ ok: true, leadId: lead.id });
  } catch (_) { return res.status(500).json({ error: 'Could not save quote request' }); }
}
